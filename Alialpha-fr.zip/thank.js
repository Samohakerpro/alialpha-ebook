document.getElementById('retourAccueil').addEventListener('click', function() {
    window.location.href = '/';
});
